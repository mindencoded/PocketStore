create function set_sequence(name character)
  returns void
language plpgsql
as $$
DECLARE result RECORD; 
BEGIN 
FOR result IN SELECT table_schema, table_name, column_name FROM information_schema.columns WHERE column_default LIKE 'nextval%' AND table_name = name LOOP 
EXECUTE format('SELECT setval(pg_get_serial_sequence(''"%1$s"."%2$s"'', ''%3$s''), CAST((SELECT MAX("%3$s") FROM "%1$s"."%2$s") AS INTEGER));', result.table_schema, result.table_name, result.column_name ); 
END LOOP; 
END;
$$;

